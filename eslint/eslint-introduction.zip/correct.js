function hello() {
  return 'hello';
}
hello();
