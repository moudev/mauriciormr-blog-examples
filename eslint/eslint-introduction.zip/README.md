# ESLint

Ejemplo para demostrar la funcionalidad de **ESLint**


**Publicación:**
- [ESLint: revisión automática de tu código JavaScript — Intentando aprender
](https://mauriciormr.xyz/posts/i54-eslint-revision-automatica-de-tu-codigo-javascript-intentando-aprender) 


# ¿Cómo ejecutar?

**Requerimientos:**
- Node.js

## Install

Entrar en la raíz del proyecto y ejecutar el comando 

```
npm install
```

# Capturas

- **Errores en consola**

![2020-08-14_16-46](https://user-images.githubusercontent.com/13499566/90298012-c1977c80-de4d-11ea-9acf-7fc60a30bbb9.png)



- **Errores en Visual Studio Code**

![2020-08-14_16-12](https://user-images.githubusercontent.com/13499566/90298016-c65c3080-de4d-11ea-8c72-d482eda5f15d.png)

