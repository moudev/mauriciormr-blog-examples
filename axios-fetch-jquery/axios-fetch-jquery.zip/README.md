# Fetch API - axios - JQuery

Ejemplo para demostrar las alternativas **axios** y **Fetch API**.

Se hace el uso de JQuery para activar los botones que realizan las peticiones.

**Publicación:**
- [¿Solo has hecho peticiones HTTP con AJAX?... Existen alternativas](https://mauriciormr.xyz/posts/i53-solo-has-hecho-peticiones-http-con-ajax-existen-alternativas) 

## Capturas

- **index.html**
<img src="https://user-images.githubusercontent.com/13499566/90067737-c7099100-dcac-11ea-8598-ca5bf224104d.png" width="500px" />
